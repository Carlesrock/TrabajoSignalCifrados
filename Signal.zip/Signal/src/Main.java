import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        cifrar();


    }

    public static void cifrar() {
        Scanner sc = new Scanner(System.in);
        char[] lista = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        ArrayList<String> mensajes = new ArrayList<>();
        ArrayList<String> cifrados = new ArrayList<>();
        String cadena = " ";
        String resultado = "";
        int contador = 0;
        int clave = 0;
        try {

            System.out.println("Cuantos mensajes quieres introducir: ");
            int nPalabras = sc.nextInt();
            sc.nextLine();
            for (int i = 0; i < nPalabras; i++) {
                System.out.println("Mensaje " + (i + 1));
                cadena = sc.nextLine();
                //Mayuscualsa jgeio jwwe
                mensajes.add(cadena);
            }

            String palabraCifrar;
            System.out.println("Introduce la clave: ");
            clave = sc.nextInt();

            for (int j = 0; j < mensajes.size(); j++) {
                palabraCifrar = mensajes.get(j).toUpperCase();
                for (int c = 0; c < palabraCifrar.length(); c++) {
                    contador = 0;
                    while (contador != lista.length) {
                        if (palabraCifrar.toUpperCase().charAt(c) == (lista[contador])) {
                            resultado = String.valueOf(lista[contador + clave]);
                            cifrados.add(resultado);
                        } else if (palabraCifrar.charAt(c) == ' ') {
                            resultado =" ";
                            cifrados.add(resultado);
                            break;
                        }
                        contador++;
                    }

                }

            }
            System.out.println("Mensaje originales: ");
            for (String e : mensajes) {
                System.out.println(e);
            }
            System.out.println("Mensajes cifrados");
            for (String e : cifrados) {
                System.out.print(e);
            }
        } catch (InputMismatchException e) {
            System.out.println(e.getMessage());
            sc.nextLine();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}